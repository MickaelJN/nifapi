<?php

namespace App\Repository;

use App\Entity\Organization;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Organization>
 *
 * @method Organization|null find($id, $lockMode = null, $lockVersion = null)
 * @method Organization|null findOneBy(array $criteria, array $orderBy = null)
 * @method Organization[]    findAll()
 * @method Organization[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class OrganizationRepository extends ServiceEntityRepository {

    public function __construct(ManagerRegistry $registry) {
        parent::__construct($registry, Organization::class);
    }

    public function add(Organization $entity, bool $flush = false): void {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(Organization $entity, bool $flush = false): void {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function getAllRibNotValid() {
        $qb = $this->createQueryBuilder('o');
        return $qb->where('o.rib IN (SELECT r FROM App\Entity\RIB r WHERE r.isValid = 0)')
                        ->orderBy('o.id', 'ASC')
                        ->getQuery()->getResult();
    }

    public function getAllRibNotValidByManager($user) {
        $qb = $this->createQueryBuilder('o');
        return $qb->where('o.rib IN (SELECT r FROM App\Entity\Rib r WHERE r.isValid = 0)')
                        ->andWhere('o IN (SELECT IDENTITY(p.organization) FROM App\Entity\Project p WHERE p.manager = :user)')
                        ->setParameter('user', $user->getId(), 'uuid')
                        ->orderBy('o.id', 'ASC')
                        ->getQuery()->getResult();
    }
    
    public function search($search, $user) {
        $qb = $this->createQueryBuilder('o');
        $qb->where('o.name LIKE :search')
                ->setParameter('search', '%' . $search . '%');

        if ($user->getType() == "association") {
            $qb->andWhere('o.id = :organization')
                    ->setParameter('organization', $user->getOrganization()->getId(), 'uuid');
        }

        $qb->addOrderBy('o.name', 'ASC');
        
        return $qb->getQuery()->getResult();
    }

//    /**
//     * @return Organization[] Returns an array of Organization objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('o')
//            ->andWhere('o.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('o.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }
//    public function findOneBySomeField($value): ?Organization
//    {
//        return $this->createQueryBuilder('o')
//            ->andWhere('o.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}

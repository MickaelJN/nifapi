<?php

namespace App\Service;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Mpdf\Mpdf;
use Twig\Environment;

class MPdfService {

    private $pdf;
    private $twig;
    private $container;

    public function __construct(Environment $twig, ContainerInterface $container) {
        $this->twig = $twig;
        $this->container = $container;
    }

    public function create($mt = 15, $mb = 15, $ml = 15, $mr = 15, $mh = 10, $mf = 10) {
        $this->pdf = new Mpdf([
            'margin_top' => $mt,
            'margin_bottom' => $mb,
            'margin_left' => $ml,
            'margin_right' => $mr,
            'margin_header' => $mh,
            'margin_footer' => $mf,
            'default_font_size' => 13,
            'default_font' => 'sans-serif'
        ]);
        $this->pdf->SetAuthor('Fondation Nif');
        $this->pdf->SetCreator('Fondation Nif');
    }

    public function generatePdf($template, $header, $footer, $name, $url) {
        $this->pdf->SetTitle($name);
        if ($header) {
            $this->pdf->SetHTMLHeader($header);
        }
        if ($footer) {
            $this->pdf->SetHTMLFooter($footer);
        }
        $this->pdf->writeHTML($template);

        header("Content-type:application/pdf");
        $this->pdf->Output($this->container->getParameter('uploadfile_directory_root') . "/" . $url . ".pdf", \Mpdf\Output\Destination::FILE);
    }

    public function showPdf($template, $header, $footer, $name) {
        $this->pdf->SetTitle($name);
        if ($header) {
            $this->pdf->SetHTMLHeader($header);
        }
        if ($footer) {
            $this->pdf->SetHTMLFooter($footer);
        }
        $this->pdf->writeHTML($template);

        header("Content-type:application/pdf");
        $this->pdf->Output($this->container->getParameter('uploadfile_directory_root') . "/" . $name . ".pdf", \Mpdf\Output\Destination::FILE);
        echo file_get_contents($this->container->getParameter('uploadfile_directory_root') . "/" . $name . '.pdf');
    }

    public function generatePDFValidation($project, $name, $url) {
        $template = $this->twig->render('pdf/validation.html.twig', array('project' => $project));
        $header = $this->twig->render('pdf/header.html.twig', array('project' => $project));
        $footer = $this->twig->render('pdf/footer.html.twig', array('project' => $project));
        $this->create();
        $this->generatePdf($template, $header, $footer, $name, $url);
    }

    public function generatePDFExtension($extension, $name, $url) {
        $template = $this->twig->render('pdf/extension.html.twig', array('extension' => $extension));
        $header = $this->twig->render('pdf/header.html.twig', array('extension' => $extension));
        $footer = $this->twig->render('pdf/footer.html.twig', array('extension' => $extension));
        $this->create();
        $this->generatePdf($template, $header, $footer, $name, $url);
    }

    public function generatePDFRecu($payment, $name, $url) {
        $template = $this->twig->render('pdf/recu.html.twig', array('payment' => $payment));
        // $header = $this->twig->render('pdf/header.html.twig');
        // $footer = $this->twig->render('pdf/footer.html.twig');
        $this->create();
        $this->generatePdf($template, null, null, $name, $url);
    }

    public function generatePDFTransfer($transfer, $name, $url) {
        $template = $this->twig->render('pdf/transfer.html.twig', array('transfer' => $transfer));
        $this->create();
        $this->generatePdf($template, null, null, $name, $url);
    }
    
    public function generatePDFProject($project, $name, $url) {
        $template = $this->twig->render('pdf/project.html.twig', array('project' => $project));
        $this->create();
        $this->showPdf($template, null, null, $name);
    }

    public function copyPdf($file, $from, $to) {
        $this->pdf = new Mpdf();
        $this->pdf->SetTitle($file->getSlug());
        $pages = $this->pdf->SetSourceFile($from);
        if (!file_exists($to)) {
            $handle = fopen($to, 'w');
            fclose($handle);
        }
        for ($i = 1; $i <= $pages; $i++) {
            $tplId = $this->pdf->ImportPage($i);
            $this->pdf->UseTemplate($tplId);
            if ($i != $pages) {
                $this->pdf->WriteHTML('<pagebreak />');
            }
        }
        header("Content-type:application/pdf");
        $this->pdf->Output($to, \Mpdf\Output\Destination::FILE);
    }

}
